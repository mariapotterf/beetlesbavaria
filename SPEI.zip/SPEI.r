
### Klima
temp=read.csv2("C:/Arbeit/Masterarbeiten/Johanna Wolf/prozessiert/Temperaturdaten.csv")
glimpse(temp)
dim(temp)
temp=data.frame(Tnr=rep(temp$id.TNR, 600), Jahr=rep(1971:2020, each=length(unique(temp$id.TNR))*600/50), Monat=rep(1:12, each=length(unique(temp$id.TNR))), temp=unlist(matrix(temp[,5:604])))# da musste ich auch ein bisschen tüfteln... Monat und Jahr wiederholen sich unterschiedlich im Datensatz. Monat wird hier automatisch bis zum Ende des Datensatzes verlängert.
tail(temp, 20)

prec=read.csv2("C:/Arbeit/Masterarbeiten/Johanna Wolf/prozessiert/Niederschlag.csv")
glimpse(prec)
dim(prec)
prec=data.frame(Tnr=rep(prec$id.TNR, 600), Jahr=rep(1971:2020, each=length(unique(prec$id.TNR))*600/50), Monat=rep(1:12, each=length(unique(prec$id.TNR))), prec=unlist(matrix(prec[,5:604])))
tail(prec, 20)

summary(prec[is.na(prec$prec),])
length(unique(prec$Tnr[is.na(prec$prec)]))
unique(prec$Tnr[is.na(prec$prec)]) 
summary(prec[prec$Tnr %in% unique(prec$Tnr[is.na(prec$prec)]),])# 3 Trakte ohne jegliche Werte, die müssen eventuell später raus, je nachdem ob die Trakte überhaupt in den anderen Daten vorkommen und ob der Dürreindex darauf basiert

klima=left_join(temp, prec) # zusammenfügen
klima$temp=klima$temp/10 #Temp hatte eine andere Nachkommastelle 
summary(klima)
head(klima)
tail(klima)

# schneller Datencheck - etwas schönere Plots für den Zeitraum, den wir im Endeffekt betrachten (2006 - 2020) wären nicht schlecht für deine Arbeit irgendwo
plot(klima$Monat, klima$temp, pch=".")
plot(klima$Monat, klima$prec, pch=".")
plot(klima$Jahr, klima$temp, pch=".")
abline(lm(klima$temp~klima$Jahr), col=2) # macht alles Sinn soweit. 



### SPEI wie im Manual
# Compute potential evapotranspiration (PET) and climatic water balance (BAL)
klima$PET <- c(thornthwaite(klima$temp, 48.7775)) # Längengrad Mitte Bayern - wahrscheinlich nicht sensitiv auf kleine Änderungen, sollte man aber checken Unterschied Norden und Süden Bayerns
klima$BAL <- c(klima$prec-klima$PET)

# Convert to a ts (time series) object for convenience
klima=klima[!is.na(klima$prec),] # erst einmal müssen nun die NAs raus

# wir haben mehrere Plots, also müssen wir das einzeln fitten
# wenn wir pro Tnr fitten ändert sich beim zusammenfügen die Anordnung, die wir brauchen, wenn wir anschließend Jahr und Monat wieder zuordnen wollen, deshalb ändere ich es zu Reihenfolge welche die folgende Schleife produziert

klima=klima[order(klima$Tnr, klima$Jahr, klima$Monat,decreasing=F),]
klima_zeit=data.frame()
for (i in unique(klima$Tnr)) {
  klima_zeit_i=ts(klima[klima$Tnr==i,c(6,7)], start = c(1971, 1), end=c(2020,12), frequency=12)
  klima_zeit_i=as.data.frame(klima_zeit_i)
  klima_zeit_i$spei1=spei(klima_zeit_i[,'BAL'], 1)$fitted # one-months SPEI
  klima_zeit_i$spei3=spei(klima_zeit_i[,'BAL'], 3)$fitted
  klima_zeit_i$spei6=spei(klima_zeit_i[,'BAL'], 6)$fitted
  klima_zeit_i$spei12=spei(klima_zeit_i[,'BAL'], 12)$fitted # tvelwe-months SPEI
  klima_zeit_i$spei24=spei(klima_zeit_i[,'BAL'], 24)$fitted
  klima_zeit_i$Tnr=i # Traktnummer aus i
  klima_zeit_i$Jahr=klima$Jahr[klima$Tnr==i]
  klima_zeit_i$Monat=klima$Monat[klima$Tnr==i]
  klima_zeit=rbind(klima_zeit, klima_zeit_i)
}

summary(klima_zeit)
identical(klima_zeit$Tnr, klima$Tnr)
klima_zeit[klima_zeit$Jahr==2018,]

# schneller Datencheck - etwas schönere Plots für den Zeitraum, den wir im Endeffekt betrachten (2006 - 2020) wären nicht schlecht für deine Arbeit irgendwo
plot(klima_zeit$Monat, klima_zeit$spei1, pch=".")
#gplot(klima_zeit$Jahr, klima_zeit$spei1, pch=".") # bringt so nicht viel, muss wohl aggregiert werden auf etwas sinnvolles (Jahr? Saison?)



### climatic water balance on a rolling basis
library(zoo)
?rollmean
klima_zeit=klima_zeit %>% group_by(Tnr) %>% mutate(cwb3=c(NA, NA, rollsum(x=BAL, k=3, align = "left")), cwb6=c(rep(NA, 5), rollsum(x=BAL, k=6, align = "left")), cwb12=c(rep(NA, 11), rollsum(x=BAL, k=12, align = "left")), cwb24=c(rep(NA, 23), rollsum(x=BAL, k=24, align = "left")))
klima_zeit
summary(klima_zeit)



### SPEIs for summer (June - August), the vegetation period (April - September), an entire year and over the past two years (those two also until September as this matters for the growth of the year) - better would be using the month of the measurement, so I am using that.
glimpse(WZEII)
glimpse(klima_zeit)
names(WZEII)[13]="Monat"
WZEII$Jahr=as.numeric(WZEII$Jahr)
WZEII=left_join(WZEII, klima_zeit)
summary(WZEII)



### check climate and weather conditions of the plots
klima_year=klima[klima$Jahr %in% c(1971:2000) & klima$Tnr %in% unique(WZEII$Tnr),] %>% group_by(Tnr, Jahr) %>% summarise_all(.funs=mean)
summary(klima_year %>% group_by(Tnr) %>% summarize_all(.funs=mean)) # min, mean, max across plots for T
klima_year=klima[klima$Jahr %in% c(1971:2000) & klima$Tnr %in% unique(WZEII$Tnr),] %>% group_by(Tnr, Jahr) %>% summarise_all(.funs=sum)
summary(klima_year %>% group_by(Tnr) %>% summarize_all(.funs=mean)) # min, mean, max across plots for P etc.

klima_year=klima[klima$Jahr %in% c(2018:2020) & klima$Tnr %in% unique(WZEII$Tnr),] %>% group_by(Tnr, Jahr) %>% summarise_all(.funs=mean)
summary(klima_year %>% group_by(Tnr) %>% summarize_all(.funs=mean)) # min, mean, max across plots for T
9.385-7.545
klima_year=klima[klima$Jahr %in% c(2018:2020) & klima$Tnr %in% unique(WZEII$Tnr),] %>% group_by(Tnr, Jahr) %>% summarise_all(.funs=sum)
summary(klima_year %>% group_by(Tnr) %>% summarize_all(.funs=mean)) # min, mean, max across plots for P etc.
1002.3-872.0

### check number of trees
WZEII %>% group_by(Baumart) %>% summarize(n())

summary(WZEII)
summary(WZEII[is.na(WZEII$spei24),]) # one more Tnr with 15 obs. that becomes NA

WZEII <- WZEII %>% drop_na()

#klima2006.2017 <- filter(klima, Jahr>2005)
ggplot(WZEII, aes(x=Jahr, y=spei12)) +
  geom_line() +
  geom_smooth(method=lm)

plot(klima2006.2017$Jahr, klima2006.2017$temp, pch=".",
     xlab="Jahr", ylab="Temperatur")
abline(lm(klima2006.2017$temp~klima2006.2017$Jahr), col=2)


#write.csv(WZEII,"C:/Users/johan/Desktop/Daten R/Dataframe1.12.2021.csv")


#save.image(file = "C:/Users/Johanna Wolf/Desktop/Masterarbeit - Kopie/R Codes/Workspace15.12.2021.RData")


################################  Analyses with SPEI ############################################


# Korrelation SPEI - Abweichung
names(WZEII)[17:20]=c("spei3" , "spei6",  "spei12", "spei24")
WZEII$spei3=c(WZEII$spei3)
WZEII$spei6=c(WZEII$spei6)
WZEII$spei12=c(WZEII$spei12)
WZEII$spei24=c(WZEII$spei24)

KorrelationI <- data.frame(matrix(ncol = 1, nrow = 1))
KorrelationI$KorSPEI3 <- cor(WZEII$Abweichung, WZEII$spei3, use = "everything", method = "pearson")
KorrelationI$KorSPEI6 <- cor(WZEII$Abweichung, WZEII$spei6, use = "everything", method = "pearson")
KorrelationI$KorSPEI12 <- cor(WZEII$Abweichung, WZEII$spei12, use = "everything", method = "pearson")
KorrelationI$KorSPEI24 <- cor(WZEII$Abweichung, WZEII$spei24, use = "everything", method = "pearson")


KorrelationII <- data.frame(matrix(ncol = 1, nrow = 1))
KorrelationII$KorSPEI3 <- cor(WZEII$absoluteAbweichung, WZEII$spei3, use = "everything", method = "pearson")
KorrelationII$KorSPEI6 <- cor(WZEII$absoluteAbweichung, WZEII$spei6, use = "everything", method = "pearson")
KorrelationII$KorSPEI12 <- cor(WZEII$absoluteAbweichung, WZEII$spei12, use = "everything", method = "pearson")
KorrelationII$KorSPEI24 <- cor(WZEII$absoluteAbweichung, WZEII$spei24, use = "everything", method = "pearson")


names(WZEII)

cormat <- round(cor(WZEII[,17:20], use="pairwise.complete.obs"),2) # only works with numeric vectors
head(cormat)

melted_cormat <- melt(cormat)
head(melted_cormat)

ggplot(data = melted_cormat, aes(x=Var1, y=Var2, fill=value)) + 
  geom_tile()

# Get lower triangle of the correlation matrix
get_lower_tri<-function(cormat){
  cormat[upper.tri(cormat)] <- NA
  return(cormat)
}
# Get upper triangle of the correlation matrix
get_upper_tri <- function(cormat){
  cormat[lower.tri(cormat)]<- NA
  return(cormat)
}

upper_tri <- get_upper_tri(cormat)
upper_tri


reorder_cormat <- function(cormat){
  # Use correlation between variables as distance
  dd <- as.dist((1-cormat)/2)
  hc <- hclust(dd)
  cormat <-cormat[hc$order, hc$order]
}


# Reorder the correlation matrix
cormat <- reorder_cormat(cormat)
upper_tri <- get_upper_tri(cormat)
# Melt the correlation matrix
melted_cormat <- melt(upper_tri, na.rm = TRUE)
# Create a ggheatmap
ggheatmap <- ggplot(melted_cormat, aes(Var2, Var1, fill = value))+
  geom_tile(color = "white")+
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                       midpoint = 0, limit = c(-1,1), space = "Lab", 
                       name="Pearson\nCorrelation") +
  theme_minimal()+ # minimal theme
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                   size = 12, hjust = 1))+
  coord_fixed()
# Print the heatmap
ggheatmap + 
  geom_text(aes(Var2, Var1, label = value), color = "black", size = 4) +
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    panel.grid.major = element_blank(),
    panel.border = element_blank(),
    panel.background = element_blank(),
    axis.ticks = element_blank(),
    legend.justification = c(1, 0),
    legend.position = c(0.6, 0.7),
    legend.direction = "horizontal")+
  guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                               title.position = "top", title.hjust = 0.5))


#  in KorrelationI steckt kein deutliches Signal für irgendeinen Zusammenhang wischen SPEI und Wuchsanomalie, aber  wir können die Auswahl anhand des größten Zusammenhangs treffen und dann schrittweise in der Korrelationsmatrix checken, was dafür rausfliegt. Dormann et al. 2012 schlagen dafür ein r von max. 0.5-0.7 vor. Ich würde eher den unteren Wert nehmen, also 0.5, aber dann bleibt nicht viel übrig. Versuchen wir es mal mit 0.6. Daraus ergeben sich:
# 1. spei6: raus muss dafür spei12, spei3, spei24, spei3_12, spei3_t1, spei6_t1
# 2. spei6_t2

### Korrelationen sind nun anders:
sort(KorrelationI) # currently KorSPEI12 is superior
sort(KorrelationII) # also here KorSPEI12 is superior

# #spei24: raus muss dafür spei12
# #spei6_t2: raus muss dafür spei1, spei3, spei6, spei3_t2
# #spei3_t1: raus muss dafür spei6_t1

# Da wir Modelle für verschiedene Baumarten haben wollen, kann man auch überlegen diesen Schritt für alle einzeln zu machen. Vorteil: man bekommt den stärksten Zusammenhang von spei und Wachstum; Nachteil: der Vergleich zwischen Baumarten ist schwieriger, weil die Variablen am Ende nicht gleich sind. Ich gehe erst einmal von Letzterem aus für die Analyse.





### Figure xy: SPEI drought over time
# I reduce dataset to the relevant plots
klima_zeit_red=klima_zeit[klima_zeit$Tnr %in% unique(WZEII$Tnr),]
klima_zeit_red=klima_zeit_red %>% group_by(Jahr, Monat) %>% summarize(spei12=mean(spei12))
summary(klima_zeit_red)
length(unique(klima_zeit_red$Tnr))
klima_zeit_red$time=as.character(paste0(klima_zeit_red$Jahr,klima_zeit_red$Monat))

barplot(klima_zeit_red$spei12[klima_zeit_red$Jahr>2016],names.arg=klima_zeit_red$Monat[klima_zeit_red$Jahr>2016])

el_plot=ggplot(klima_zeit_red[klima_zeit_red$Jahr>2016,], aes(x=time, y=spei12)) + 
  geom_bar(stat="identity")+ 
  scale_x_discrete(labels=rep("", 48)) +
  #scale_x_discrete(labels=rep(c("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"), 4)) +
  geom_col(aes(fill = spei12)) + 
  scale_fill_gradient2(low = "darkred", high = "darkblue", mid = "grey80",                             midpoint = 0, space = "Lab", 
                       name="") +
  labs(x = "", y= "12-month SPEI",color='')+
  theme_classic(base_size = 18)+
  theme(panel.border = element_rect(colour = "black", fill=NA, size=1.5)) +
  geom_hline(yintercept = 0, size=1) +
  geom_hline(yintercept = -1, linetype = "dashed", size=2)
  #+  theme(axis.text.x = element_text(angle = 90, hjust = 1))
